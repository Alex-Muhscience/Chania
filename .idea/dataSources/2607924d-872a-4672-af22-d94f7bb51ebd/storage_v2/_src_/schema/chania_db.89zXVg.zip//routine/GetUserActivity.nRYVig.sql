create
    definer = root@localhost procedure GetUserActivity(IN user_id int, IN days_back int)
BEGIN
    SELECT
        DATE(created_at) as activity_date,
        COUNT(*) as activity_count,
        GROUP_CONCAT(DISTINCT action) as actions
    FROM admin_logs
    WHERE user_id = user_id
    AND created_at >= DATE_SUB(NOW(), INTERVAL days_back DAY)
    GROUP BY DATE(created_at)
    ORDER BY activity_date DESC;
END;

