create definer = root@localhost view active_programs as
select `p`.`id`                                                AS `id`,
       `p`.`title`                                             AS `title`,
       `p`.`slug`                                              AS `slug`,
       `p`.`description`                                       AS `description`,
       `p`.`short_description`                                 AS `short_description`,
       `p`.`category`                                          AS `category`,
       `p`.`duration`                                          AS `duration`,
       `p`.`difficulty_level`                                  AS `difficulty_level`,
       `p`.`fee`                                               AS `fee`,
       `p`.`max_participants`                                  AS `max_participants`,
       `p`.`start_date`                                        AS `start_date`,
       `p`.`end_date`                                          AS `end_date`,
       `p`.`image_path`                                        AS `image_path`,
       `p`.`instructor_name`                                   AS `instructor_name`,
       `p`.`location`                                          AS `location`,
       `p`.`is_featured`                                       AS `is_featured`,
       `p`.`is_active`                                         AS `is_active`,
       `p`.`is_online`                                         AS `is_online`,
       `p`.`view_count`                                        AS `view_count`,
       `p`.`application_count`                                 AS `application_count`,
       `p`.`created_by`                                        AS `created_by`,
       `p`.`created_at`                                        AS `created_at`,
       `p`.`updated_at`                                        AS `updated_at`,
       `p`.`deleted_at`                                        AS `deleted_at`,
       `u`.`username`                                          AS `created_by_name`,
       (select count(0)
        from `chania_db`.`applications`
        where `chania_db`.`applications`.`program_id` = `p`.`id`
          and `chania_db`.`applications`.`deleted_at` is null) AS `current_applications`
from (`chania_db`.`programs` `p` left join `chania_db`.`users` `u` on (`p`.`created_by` = `u`.`id`))
where `p`.`is_active` = 1
  and `p`.`deleted_at` is null;

