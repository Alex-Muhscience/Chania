create definer = root@localhost trigger programs_insert_log
    after insert
    on programs
    for each row
BEGIN
    INSERT INTO admin_logs (user_id, action, entity_type, entity_id, new_values, ip_address)
    VALUES (NEW.created_by, 'CREATE', 'program', NEW.id, JSON_OBJECT('title', NEW.title, 'category', NEW.category), @user_ip);
END;

