create definer = root@localhost view recent_applications as
select `a`.`id`                                       AS `id`,
       `a`.`program_id`                               AS `program_id`,
       `a`.`application_number`                       AS `application_number`,
       `a`.`first_name`                               AS `first_name`,
       `a`.`last_name`                                AS `last_name`,
       `a`.`email`                                    AS `email`,
       `a`.`phone`                                    AS `phone`,
       `a`.`date_of_birth`                            AS `date_of_birth`,
       `a`.`gender`                                   AS `gender`,
       `a`.`address`                                  AS `address`,
       `a`.`city`                                     AS `city`,
       `a`.`country`                                  AS `country`,
       `a`.`education_level`                          AS `education_level`,
       `a`.`education_details`                        AS `education_details`,
       `a`.`work_experience`                          AS `work_experience`,
       `a`.`motivation`                               AS `motivation`,
       `a`.`status`                                   AS `status`,
       `a`.`reviewed_by`                              AS `reviewed_by`,
       `a`.`reviewed_at`                              AS `reviewed_at`,
       `a`.`notes`                                    AS `notes`,
       `a`.`payment_status`                           AS `payment_status`,
       `a`.`ip_address`                               AS `ip_address`,
       `a`.`submitted_at`                             AS `submitted_at`,
       `a`.`updated_at`                               AS `updated_at`,
       `a`.`deleted_at`                               AS `deleted_at`,
       `p`.`title`                                    AS `program_title`,
       `p`.`category`                                 AS `program_category`,
       concat(`a`.`first_name`, ' ', `a`.`last_name`) AS `full_name`
from (`chania_db`.`applications` `a` join `chania_db`.`programs` `p` on (`a`.`program_id` = `p`.`id`))
where `a`.`deleted_at` is null
order by `a`.`submitted_at` desc;

