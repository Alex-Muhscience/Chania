create definer = root@localhost view dashboard_stats as
select (select count(0)
        from `chania_db`.`programs`
        where `chania_db`.`programs`.`is_active` = 1
          and `chania_db`.`programs`.`deleted_at` is null)                                             AS `active_programs`,
       (select count(0)
        from `chania_db`.`applications`
        where `chania_db`.`applications`.`status` = 'pending'
          and `chania_db`.`applications`.`deleted_at` is null)                                         AS `pending_applications`,
       (select count(0)
        from `chania_db`.`applications`
        where `chania_db`.`applications`.`status` = 'approved'
          and `chania_db`.`applications`.`deleted_at` is null)                                         AS `approved_applications`,
       (select count(0)
        from `chania_db`.`users`
        where `chania_db`.`users`.`is_active` = 1)                                                     AS `active_users`,
       (select count(0)
        from `chania_db`.`contacts`
        where `chania_db`.`contacts`.`replied_at` is null)                                             AS `unread_contacts`;

