create definer = root@localhost trigger applications_status_log
    after update
    on applications
    for each row
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO admin_logs (user_id, action, entity_type, entity_id, old_values, new_values, ip_address)
        VALUES (NEW.reviewed_by, 'STATUS_CHANGE', 'application', NEW.id,
                JSON_OBJECT('status', OLD.status),
                JSON_OBJECT('status', NEW.status),
                @user_ip);
    END IF;
END;

