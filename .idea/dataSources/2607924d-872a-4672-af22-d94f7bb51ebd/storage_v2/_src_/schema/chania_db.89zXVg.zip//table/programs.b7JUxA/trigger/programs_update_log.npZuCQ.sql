create definer = root@localhost trigger programs_update_log
    after update
    on programs
    for each row
BEGIN
    INSERT INTO admin_logs (user_id, action, entity_type, entity_id, old_values, new_values, ip_address)
    VALUES (NEW.created_by, 'UPDATE', 'program', NEW.id,
            JSON_OBJECT('title', OLD.title, 'category', OLD.category),
            JSON_OBJECT('title', NEW.title, 'category', NEW.category),
            @user_ip);
END;

